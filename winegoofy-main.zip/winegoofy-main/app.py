# app.py - WineGoofy starter script
from flask import Flask, request, jsonify

app = Flask(__name__)

# Welcome endpoint
@app.route("/welcome", methods=["GET"])
def welcome():
    return jsonify({"message": "Hello! Welcome to WineGoofy 🍷. Which language do you prefer?"})

# Food & Wine pairing endpoint (starter)
@app.route("/foodwine", methods=["POST"])
def food_wine():
    data = request.json
    dish = data.get("dish", "bobotie")
    budget = data.get("budget", "mid-range")
    return jsonify({
        "message": f"Here are 2-3 wine suggestions for {dish} ({budget} category). 🍷"
    })

# Lead Generation endpoint (starter)
@app.route("/leadgen", methods=["POST"])
def lead_gen():
    data = request.json
    name = data.get("name", "Guest")
    whatsapp = data.get("whatsapp", "")
    preference = data.get("preference", "mid-range")
    return jsonify({
        "message": f"Thanks {name}! We saved your lead with preference {preference}."
    })

if __name__ == "__main__":
    app.run(debug=True)
